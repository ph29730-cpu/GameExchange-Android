
import React, { useMemo, useState } from "react";
import {
  SafeAreaView, StatusBar, StyleSheet, Text, TextInput, TouchableOpacity,
  View, ScrollView, FlatList, Alert
} from "react-native";

type Listing = {
  id: string;
  name: string;
  category: string;
  price: number;
  qty: number;
  seller: string;
  description: string;
};

type Tab = "Home" | "Marketplace" | "Sell" | "Messages" | "Account";
type AccountView = "main" | "seller" | "admin";

const PLATFORM_FEE = 0.05;

const initialListings: Listing[] = [
  { id:"1", name:"Rattler Assault Rifle", category:"Weapons", price:24.99, qty:3, seller:"RaiderPro", description:"High-damage weapon listing. Coordinate delivery in chat." },
  { id:"2", name:"Advanced Shield Core", category:"Gear", price:12.99, qty:5, seller:"NightRaid", description:"Popular defensive item listing." },
  { id:"3", name:"Power Cell", category:"Resources", price:3.50, qty:10, seller:"LootHunter", description:"Resource bundle." },
  { id:"4", name:"Rare Blueprint", category:"Blueprints", price:8.99, qty:2, seller:"ShadowTrader", description:"Rare blueprint listing." },
];

const categories = ["All","Weapons","Gear","Resources","Blueprints","Materials","Other"];

export default function App() {
  const [tab, setTab] = useState<Tab>("Home");
  const [listings, setListings] = useState<Listing[]>(initialListings);
  const [selected, setSelected] = useState<Listing | null>(null);
  const [search, setSearch] = useState("");
  const [accountView, setAccountView] = useState<AccountView>("main");
  const [category, setCategory] = useState("All");

  const filtered = useMemo(() => listings.filter(x => {
    const q = search.trim().toLowerCase();
    const matchesText = !q || x.name.toLowerCase().includes(q) || x.seller.toLowerCase().includes(q);
    const matchesCat = category === "All" || x.category === category;
    return matchesText && matchesCat;
  }), [listings, search, category]);

  const totalSales = 12430;
  const platformFees = totalSales * PLATFORM_FEE;

  function addListing(l: Omit<Listing,"id"|"seller">) {
    setListings(prev => [{...l, id:String(Date.now()), seller:"You"}, ...prev]);
    setTab("Marketplace");
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" />
      <View style={styles.shell}>
        {selected ? (
          <ItemDetails item={selected} onBack={()=>setSelected(null)} />
        ) : tab === "Home" ? (
          <Home onBrowse={()=>setTab("Marketplace")} listings={listings.slice(0,3)} onSelect={setSelected}/>
        ) : tab === "Marketplace" ? (
          <Marketplace
            items={filtered}
            search={search}
            setSearch={setSearch}
            category={category}
            setCategory={setCategory}
            onSelect={setSelected}
          />
        ) : tab === "Sell" ? (
          <SellForm onAdd={addListing}/>
        ) : tab === "Messages" ? (
          <Messages/>
        ) : (
          <Account
            view={accountView}
            setView={setAccountView}
            listings={listings}
            totalSales={totalSales}
            platformFees={platformFees}
          />
        )}

        {!selected && <BottomNav tab={tab} setTab={(t)=>{ setTab(t); if(t!=="Account") setAccountView("main"); }} />}
      </View>
    </SafeAreaView>
  );
}

function Header({title, subtitle}:{title:string; subtitle?:string}) {
  return <View style={styles.header}>
    <Text style={styles.title}>{title}</Text>
    {subtitle ? <Text style={styles.muted}>{subtitle}</Text> : null}
  </View>
}

function Home({onBrowse, listings, onSelect}:{onBrowse:()=>void; listings:Listing[]; onSelect:(x:Listing)=>void}) {
  return <ScrollView contentContainerStyle={styles.content}>
    <View style={styles.brandRow}>
      <View style={styles.logo}><Text style={styles.logoText}>GE</Text></View>
      <View><Text style={styles.brand}>Game<Text style={styles.blue}>Exchange</Text></Text><Text style={styles.tagline}>BUY. SELL. TRADE. GAME.</Text></View>
    </View>

    <TextInput style={styles.search} placeholder="Search games, items, or sellers..." placeholderTextColor="#7f93a3" />

    <View style={styles.hero}>
      <Text style={styles.heroEyebrow}>ARC RAIDERS</Text>
      <Text style={styles.heroTitle}>GEAR UP{'\n'}GET AHEAD.</Text>
      <Text style={styles.muted}>Player-to-player marketplace</Text>
      <TouchableOpacity style={styles.primaryBtn} onPress={onBrowse}><Text style={styles.primaryText}>Browse ARC Raiders →</Text></TouchableOpacity>
    </View>

    <SectionTitle title="Featured Items"/>
    {listings.map(x => <ListingCard key={x.id} item={x} onPress={()=>onSelect(x)} />)}

    <View style={styles.notice}>
      <Text style={styles.noticeTitle}>GameExchange fee</Text>
      <Text style={styles.noticeText}>Sellers set their own prices. GameExchange takes 5% from completed sales.</Text>
    </View>
  </ScrollView>
}

function Marketplace({items, search, setSearch, category, setCategory, onSelect}:{
  items:Listing[]; search:string; setSearch:(s:string)=>void; category:string; setCategory:(s:string)=>void; onSelect:(x:Listing)=>void;
}) {
  return <View style={styles.flex}>
    <View style={styles.contentNoBottom}>
      <Header title="Marketplace" subtitle="ARC Raiders"/>
      <TextInput value={search} onChangeText={setSearch} style={styles.search} placeholder="Search ARC Raiders items..." placeholderTextColor="#7f93a3" />
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{maxHeight:48, marginBottom:10}}>
        {categories.map(c => <TouchableOpacity key={c} onPress={()=>setCategory(c)} style={[styles.chip, category===c && styles.chipActive]}><Text style={styles.chipText}>{c}</Text></TouchableOpacity>)}
      </ScrollView>
    </View>
    <FlatList contentContainerStyle={{paddingHorizontal:16,paddingBottom:120}} data={items} keyExtractor={x=>x.id} renderItem={({item})=><ListingCard item={item} onPress={()=>onSelect(item)}/>} />
  </View>
}

function ListingCard({item,onPress}:{item:Listing;onPress:()=>void}) {
  return <TouchableOpacity style={styles.card} onPress={onPress}>
    <View style={styles.itemIcon}><Text style={{fontSize:24}}>🎮</Text></View>
    <View style={{flex:1}}>
      <Text style={styles.cardTitle}>{item.name}</Text>
      <Text style={styles.muted}>{item.category} · {item.seller}</Text>
      <Text style={styles.price}>${item.price.toFixed(2)} <Text style={styles.muted}>  Qty: {item.qty}</Text></Text>
    </View>
    <Text style={styles.chev}>›</Text>
  </TouchableOpacity>
}

function ItemDetails({item,onBack}:{item:Listing;onBack:()=>void}) {
  const fee = item.price * PLATFORM_FEE;
  const sellerNet = item.price - fee;
  return <ScrollView contentContainerStyle={styles.content}>
    <TouchableOpacity onPress={onBack}><Text style={styles.back}>‹ Back</Text></TouchableOpacity>
    <View style={styles.itemHero}><Text style={{fontSize:72}}>🎮</Text></View>
    <Text style={styles.title}>{item.name}</Text>
    <Text style={styles.muted}>ARC Raiders · {item.category}</Text>
    <Text style={styles.bigPrice}>${item.price.toFixed(2)}</Text>
    <Text style={styles.body}>{item.description}</Text>

    <View style={styles.card}>
      <View style={{flex:1}}>
        <Text style={styles.cardTitle}>{item.seller}</Text>
        <Text style={styles.muted}>Seller · 4.8 ★</Text>
      </View>
      <Text style={styles.blue}>View Seller</Text>
    </View>

    <View style={styles.summary}>
      <SummaryLine label="Item price" value={`$${item.price.toFixed(2)}`}/>
      <SummaryLine label="GameExchange fee (5%)" value={`$${fee.toFixed(2)}`}/>
      <SummaryLine label="Seller receives" value={`$${sellerNet.toFixed(2)}`}/>
    </View>

    <TouchableOpacity style={styles.primaryBtn} onPress={()=>Alert.alert("Checkout demo","Payment processing is not connected yet. This prototype shows the marketplace flow only.")}>
      <Text style={styles.primaryText}>Buy Now</Text>
    </TouchableOpacity>
  </ScrollView>
}

function SellForm({onAdd}:{onAdd:(l:Omit<Listing,"id"|"seller">)=>void}) {
  const [name,setName]=useState("");
  const [cat,setCat]=useState("Weapons");
  const [price,setPrice]=useState("");
  const [qty,setQty]=useState("1");
  const [desc,setDesc]=useState("");
  const numericPrice = Number(price)||0;
  const fee = numericPrice*PLATFORM_FEE;
  const sellerNet = numericPrice-fee;

  return <ScrollView contentContainerStyle={styles.content}>
    <Header title="Sell an Item" subtitle="You choose your price"/>
    <Label text="Item name"/><TextInput style={styles.input} value={name} onChangeText={setName} placeholder="e.g. Rattler Assault Rifle" placeholderTextColor="#7f93a3"/>
    <Label text="Category"/><TextInput style={styles.input} value={cat} onChangeText={setCat}/>
    <View style={styles.row}>
      <View style={{flex:1,marginRight:8}}><Label text="Price (USD)"/><TextInput style={styles.input} keyboardType="decimal-pad" value={price} onChangeText={setPrice} placeholder="0.00" placeholderTextColor="#7f93a3"/></View>
      <View style={{width:100}}><Label text="Qty"/><TextInput style={styles.input} keyboardType="number-pad" value={qty} onChangeText={setQty}/></View>
    </View>
    <Label text="Description"/><TextInput style={[styles.input,{height:110,textAlignVertical:"top"}]} multiline value={desc} onChangeText={setDesc} placeholder="Describe the item and delivery details..." placeholderTextColor="#7f93a3"/>

    <View style={styles.summary}>
      <SummaryLine label="Your price" value={`$${numericPrice.toFixed(2)}`}/>
      <SummaryLine label="GameExchange fee (5%)" value={`-$${fee.toFixed(2)}`}/>
      <SummaryLine label="You receive" value={`$${sellerNet.toFixed(2)}`}/>
    </View>

    <TouchableOpacity style={styles.primaryBtn} onPress={()=>{
      if(!name.trim() || numericPrice<=0) return Alert.alert("Add item details","Enter an item name and a price above $0.");
      onAdd({name:name.trim(),category:cat.trim()||"Other",price:numericPrice,qty:Math.max(1,Number(qty)||1),description:desc.trim()||"No description provided."});
    }}>
      <Text style={styles.primaryText}>List Item</Text>
    </TouchableOpacity>
  </ScrollView>
}

function Messages() {
  const rows = [
    ["RaiderPro","Thanks! I'll get that sent over...","2m"],
    ["LootHunter","Is this still available?","15m"],
    ["GameExchange","Your order has been confirmed.","2h"],
    ["ShadowTrader","Can you do $20?","5h"],
    ["NightRaid","Item delivered. Appreciate it!","1d"],
  ];
  return <ScrollView contentContainerStyle={styles.content}>
    <Header title="Messages" subtitle="Buyer and seller chat"/>
    {rows.map(([name,msg,time])=><View style={styles.message} key={name}><View style={styles.avatar}><Text>👤</Text></View><View style={{flex:1}}><Text style={styles.cardTitle}>{name}</Text><Text style={styles.muted}>{msg}</Text></View><Text style={styles.muted}>{time}</Text></View>)}
  </ScrollView>
}

function Account({view,setView,listings,totalSales,platformFees}:{
  view:AccountView;setView:(v:AccountView)=>void;listings:Listing[];totalSales:number;platformFees:number;
}) {
  if(view==="seller") return <Dashboard title="Seller Dashboard" onBack={()=>setView("main")} stats={[
    ["Total Sales","$342.50"],["Your Earnings","$325.38"],["Items Sold","17"],["Rating","4.9 ★"]
  ]}/>;
  if(view==="admin") return <Dashboard title="Admin Dashboard" onBack={()=>setView("main")} stats={[
    ["Total Users","1,482"],["Active Listings",String(listings.length+608)],["Total Sales (30d)",`$${totalSales.toLocaleString()}`],["Your Fees (5%)",`$${platformFees.toFixed(2)}`]
  ]}/>;

  return <ScrollView contentContainerStyle={styles.content}>
    <Header title="My Account" subtitle="RaiderKing"/>
    <View style={styles.profile}>
      <View style={styles.avatarBig}><Text style={{fontSize:32}}>👤</Text></View>
      <View><Text style={styles.cardTitle}>RaiderKing</Text><Text style={styles.muted}>Member since Sep 2026</Text></View>
    </View>
    <View style={styles.statsRow}>
      <MiniStat n="12" label="Listings"/><MiniStat n="28" label="Sales"/><MiniStat n="4.9" label="Rating"/>
    </View>
    <Menu label="My Purchases"/>
    <Menu label="My Listings"/>
    <Menu label="Seller Dashboard" onPress={()=>setView("seller")}/>
    <Menu label="Payment Methods"/>
    <Menu label="Account Settings"/>
    <Menu label="Admin Dashboard" onPress={()=>setView("admin")}/>
  </ScrollView>
}

function Dashboard({title,onBack,stats}:{title:string;onBack:()=>void;stats:string[][]}) {
  return <ScrollView contentContainerStyle={styles.content}>
    <TouchableOpacity onPress={onBack}><Text style={styles.back}>‹ Account</Text></TouchableOpacity>
    <Header title={title}/>
    <View style={styles.grid}>
      {stats.map(([label,value])=><View style={styles.statCard} key={label}><Text style={styles.statValue}>{value}</Text><Text style={styles.muted}>{label}</Text></View>)}
    </View>
    <Menu label="Users"/>
    <Menu label="Listings"/>
    <Menu label="Orders & Transactions"/>
    <Menu label="Reports & Disputes"/>
    <Menu label="Fee Settings (5%)"/>
    <Menu label="System Settings"/>
  </ScrollView>
}

function BottomNav({tab,setTab}:{tab:Tab;setTab:(t:Tab)=>void}) {
  const tabs:Tab[]=["Home","Marketplace","Sell","Messages","Account"];
  return <View style={styles.nav}>{tabs.map(t=><TouchableOpacity key={t} style={styles.navItem} onPress={()=>setTab(t)}><Text style={[styles.navIcon,tab===t&&styles.blue]}>{t==="Home"?"⌂":t==="Marketplace"?"▦":t==="Sell"?"＋":t==="Messages"?"✉":"●"}</Text><Text style={[styles.navText,tab===t&&styles.blue]}>{t}</Text></TouchableOpacity>)}</View>
}

function SectionTitle({title}:{title:string}) { return <Text style={styles.sectionTitle}>{title}</Text> }
function Label({text}:{text:string}) { return <Text style={styles.label}>{text}</Text> }
function SummaryLine({label,value}:{label:string;value:string}) { return <View style={styles.summaryLine}><Text style={styles.muted}>{label}</Text><Text style={styles.cardTitle}>{value}</Text></View> }
function Menu({label,onPress}:{label:string;onPress?:()=>void}) { return <TouchableOpacity style={styles.menu} onPress={onPress}><Text style={styles.cardTitle}>{label}</Text><Text style={styles.chev}>›</Text></TouchableOpacity> }
function MiniStat({n,label}:{n:string;label:string}) { return <View style={{alignItems:"center",flex:1}}><Text style={styles.statValue}>{n}</Text><Text style={styles.muted}>{label}</Text></View> }

const styles = StyleSheet.create({
  safe:{flex:1,backgroundColor:"#061018"},
  shell:{flex:1,backgroundColor:"#061018"},
  flex:{flex:1},
  content:{padding:16,paddingBottom:120},
  contentNoBottom:{padding:16,paddingBottom:4},
  header:{marginBottom:14},
  title:{color:"#f3f8fc",fontSize:26,fontWeight:"800"},
  brandRow:{flexDirection:"row",alignItems:"center",marginBottom:16},
  logo:{width:52,height:52,borderRadius:16,backgroundColor:"#0f82ff",alignItems:"center",justifyContent:"center",marginRight:12},
  logoText:{color:"white",fontWeight:"900",fontSize:22},
  brand:{color:"white",fontSize:24,fontWeight:"900"},
  tagline:{color:"#97a7b5",fontSize:10,letterSpacing:1.5,fontWeight:"700"},
  blue:{color:"#27a3ff"},
  muted:{color:"#8fa1af",fontSize:13},
  body:{color:"#d4dde5",fontSize:15,lineHeight:22,marginVertical:14},
  search:{backgroundColor:"#102230",borderColor:"#25465d",borderWidth:1,borderRadius:10,padding:13,color:"white",marginBottom:14},
  hero:{backgroundColor:"#10283b",borderRadius:16,padding:20,marginBottom:18,borderColor:"#1c4a66",borderWidth:1},
  heroEyebrow:{color:"#27a3ff",fontWeight:"900",letterSpacing:1.4},
  heroTitle:{color:"white",fontWeight:"900",fontSize:30,marginVertical:8},
  primaryBtn:{backgroundColor:"#0f88ff",padding:15,borderRadius:10,alignItems:"center",marginTop:14},
  primaryText:{color:"white",fontWeight:"800"},
  sectionTitle:{color:"white",fontSize:18,fontWeight:"800",marginVertical:10},
  card:{backgroundColor:"#0c1c27",borderColor:"#18384a",borderWidth:1,borderRadius:12,padding:12,marginBottom:10,flexDirection:"row",alignItems:"center"},
  itemIcon:{width:58,height:58,borderRadius:10,backgroundColor:"#142b3a",alignItems:"center",justifyContent:"center",marginRight:12},
  cardTitle:{color:"#f4f8fb",fontWeight:"700"},
  price:{color:"#62d889",fontSize:16,fontWeight:"800",marginTop:5},
  chev:{color:"#7f93a3",fontSize:30},
  notice:{backgroundColor:"#0c1c27",padding:16,borderRadius:12,marginTop:8,borderColor:"#24465c",borderWidth:1},
  noticeTitle:{color:"white",fontWeight:"800",marginBottom:6},
  noticeText:{color:"#a9b7c2",lineHeight:20},
  chip:{paddingVertical:9,paddingHorizontal:14,borderRadius:10,backgroundColor:"#10222f",marginRight:8,borderWidth:1,borderColor:"#1b3b4f"},
  chipActive:{backgroundColor:"#0f88ff"},
  chipText:{color:"white",fontWeight:"700",fontSize:12},
  back:{color:"#38a9ff",fontWeight:"700",fontSize:16,marginBottom:16},
  itemHero:{height:210,borderRadius:16,backgroundColor:"#102838",alignItems:"center",justifyContent:"center",marginBottom:18},
  bigPrice:{fontSize:30,color:"white",fontWeight:"900",marginTop:8},
  summary:{backgroundColor:"#0b1922",borderRadius:12,padding:14,borderColor:"#19394b",borderWidth:1,marginVertical:12},
  summaryLine:{flexDirection:"row",justifyContent:"space-between",paddingVertical:7},
  label:{color:"#dce6ed",fontWeight:"700",marginBottom:6,marginTop:8},
  input:{backgroundColor:"#102230",borderColor:"#25465d",borderWidth:1,borderRadius:10,padding:13,color:"white",marginBottom:8},
  row:{flexDirection:"row"},
  message:{flexDirection:"row",alignItems:"center",paddingVertical:14,borderBottomColor:"#17303f",borderBottomWidth:1},
  avatar:{width:42,height:42,borderRadius:21,backgroundColor:"#17384e",alignItems:"center",justifyContent:"center",marginRight:11},
  profile:{flexDirection:"row",alignItems:"center",marginBottom:18},
  avatarBig:{width:68,height:68,borderRadius:34,backgroundColor:"#17384e",alignItems:"center",justifyContent:"center",marginRight:14},
  statsRow:{flexDirection:"row",backgroundColor:"#0c1c27",borderRadius:12,padding:15,marginBottom:12},
  statValue:{color:"#f7fbff",fontSize:22,fontWeight:"900"},
  menu:{backgroundColor:"#0b1922",borderBottomColor:"#19394b",borderBottomWidth:1,paddingVertical:16,paddingHorizontal:12,flexDirection:"row",justifyContent:"space-between",alignItems:"center"},
  grid:{flexDirection:"row",flexWrap:"wrap",justifyContent:"space-between",marginBottom:12},
  statCard:{width:"48%",backgroundColor:"#0c1c27",borderRadius:12,padding:16,marginBottom:10,borderColor:"#18384a",borderWidth:1},
  nav:{position:"absolute",left:0,right:0,bottom:0,height:78,backgroundColor:"#07141d",borderTopColor:"#18384a",borderTopWidth:1,flexDirection:"row",justifyContent:"space-around",paddingTop:8},
  navItem:{alignItems:"center",width:"20%"},
  navIcon:{color:"#8fa1af",fontSize:23,height:28},
  navText:{color:"#8fa1af",fontSize:10,fontWeight:"700"}
});

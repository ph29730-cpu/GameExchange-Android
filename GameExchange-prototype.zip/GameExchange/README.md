# GameExchange Prototype

A mobile-first Expo / React Native prototype for the GameExchange marketplace.

## Included
- ARC Raiders-focused home screen
- Marketplace with search and category filters
- Item detail screen
- Seller-created listings with custom prices
- Automatic 5% GameExchange fee calculation
- Seller earnings preview
- Messages screen
- Account screen
- Seller dashboard
- Admin dashboard showing 5% fee revenue

## Important
This prototype DOES NOT process real payments yet. The Buy Now button intentionally shows a demo alert.

For a production marketplace, payment onboarding, seller payouts, identity/compliance checks, refunds, disputes, marketplace terms, and game/publisher policy checks should be implemented before launch.

## Run it
1. Install Node.js.
2. In this folder run:
   npm install
3. Start Expo:
   npm start
4. Open with Expo Go on Android, or run an emulator.

## Current platform fee
5%, configured in App.tsx as:
`const PLATFORM_FEE = 0.05;`

## Next recommended build steps
- Supabase/Firebase authentication and database
- Real seller profiles and listing photos
- Cloud messaging/chat
- Marketplace payments and seller payouts
- Reporting/dispute workflow
- Push notifications
- App Store / Play Store release configuration
